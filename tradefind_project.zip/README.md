# TradeFind — AI Import/Export Directory

AI-powered web app to search global importers and exporters.

## Features
- Classic search by country, product, trade type
- AI semantic search (petroleum finds oil)
- Similar company recommendations
- AI chatbot powered by Groq Llama 3
- Excel export with all contact details

## Tech Stack
Python, Flask, SQLite, sentence-transformers, scikit-learn, Groq API

## How to Run
1. Open TradeFind_FINAL.ipynb in Google Colab
2. Save Groq API key in Colab Secrets as: API
3. Run Cell 1, Cell 2, Cell 3
4. Click the URL that appears

## Get Free Groq API Key
https://console.groq.com
