import sys
sys.path.insert(0, "/content/tradefind")
from flask import Flask, render_template, request, jsonify, send_file
import sqlite3, openpyxl, io, os
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
app=Flask(__name__,template_folder="/content/tradefind/templates",static_folder="/content/tradefind/static")
DB="/content/tradefind/data/trade.db"
def _load_ai():
    try:
        from ai.nlp_search  import build_index as bn, semantic_search
        from ai.recommender import build_index as br, get_similar
        bn(); br(); print("[App] AI ready!"); return semantic_search, get_similar
    except Exception as e: print(f"[App] AI skipped: {e}"); return None, None
ss,gs=_load_ai()
def db():
    c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
@app.route("/")
def index():
    c=db()
    countries=[r["country"] for r in c.execute("SELECT DISTINCT country FROM companies ORDER BY country").fetchall()]
    products =[r["product"]  for r in c.execute("SELECT DISTINCT product  FROM companies ORDER BY product").fetchall()]
    c.close()
    return render_template("index.html",countries=countries,products=products,ai_enabled=ss is not None)
@app.route("/search")
def search():
    co=request.args.get("country","").strip(); pr=request.args.get("product","").strip(); tt=request.args.get("trade_type","").strip()
    c=db(); q="SELECT * FROM companies WHERE 1=1"; p=[]
    if co: q+=" AND LOWER(country)=LOWER(?)"; p.append(co)
    if pr: q+=" AND LOWER(product)=LOWER(?)"; p.append(pr)
    if tt: q+=" AND LOWER(trade_type)=LOWER(?)"; p.append(tt)
    rows=c.execute(q,p).fetchall(); c.close()
    return jsonify([dict(r) for r in rows])
@app.route("/company/<int:cid>")
def detail(cid):
    c=db(); row=c.execute("SELECT * FROM companies WHERE id=?",(cid,)).fetchone(); c.close()
    if not row: return "Not found",404
    sim=[]
    if gs:
        try: sim=gs(cid,top_k=4)
        except: pass
    return render_template("detail.html",company=dict(row),similar=sim)
@app.route("/export")
def export():
    co=request.args.get("country",""); pr=request.args.get("product",""); tt=request.args.get("trade_type","")
    c=db(); q="SELECT * FROM companies WHERE 1=1"; p=[]
    if co: q+=" AND LOWER(country)=LOWER(?)"; p.append(co)
    if pr: q+=" AND LOWER(product)=LOWER(?)"; p.append(pr)
    if tt: q+=" AND LOWER(trade_type)=LOWER(?)"; p.append(tt)
    rows=c.execute(q,p).fetchall(); c.close()
    wb=openpyxl.Workbook(); ws=wb.active; ws.title="Trade Directory"
    hdrs=["SR#","Company Name","Contact Person","Phone 1","Phone 2","Mobile","Email 1","Email 2"]
    hf=PatternFill("solid",fgColor="1B3A6B"); hn=Font(bold=True,color="FFFFFF",size=11)
    af=PatternFill("solid",fgColor="EEF3FB"); bs=Side(style="thin",color="C5CDD9")
    cb=Border(left=bs,right=bs,top=bs,bottom=bs); cw=[6,32,24,18,18,18,28,28]
    for i,(h,w) in enumerate(zip(hdrs,cw),1):
        cell=ws.cell(row=1,column=i,value=h); cell.font=hn; cell.fill=hf
        cell.alignment=Alignment(horizontal="center",vertical="center"); cell.border=cb
        ws.column_dimensions[cell.column_letter].width=w
    ws.row_dimensions[1].height=22
    for sr,row in enumerate(rows,1):
        d=[sr,row["company_name"],row["contact_person"],row["phone1"],row["phone2"],row["mobile"],row["email1"],row["email2"]]
        for col,val in enumerate(d,1):
            cell=ws.cell(row=sr+1,column=col,value=val or ""); cell.alignment=Alignment(vertical="center"); cell.border=cb
            if sr%2==0: cell.fill=af
    ws.freeze_panes="A2"; ws.auto_filter.ref=ws.dimensions
    buf=io.BytesIO(); wb.save(buf); buf.seek(0)
    return send_file(buf,as_attachment=True,download_name=f"trade_{tt}_{pr}_{co}.xlsx".replace(" ","_"),mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
@app.route("/ai/search")
def ai_search():
    if not ss: return jsonify({"error":"AI not available"}),503
    q=request.args.get("q","").strip()
    if not q: return jsonify({"error":"q required"}),400
    try: return jsonify(ss(q,country=request.args.get("country",""),trade_type=request.args.get("trade_type","")))
    except Exception as e: return jsonify({"error":str(e)}),500
@app.route("/ai/similar/<int:cid>")
def ai_similar(cid):
    if not gs: return jsonify([])
    try: return jsonify(gs(cid,top_k=4))
    except Exception as e: return jsonify({"error":str(e)}),500
@app.route("/ai/chat",methods=["POST"])
def ai_chat():
    from ai.chatbot import chat
    d=request.get_json(silent=True) or {}; msg=d.get("message","").strip()
    if not msg: return jsonify({"error":"message required"}),400
    return jsonify(chat(msg,history=d.get("history",[])))
if __name__=="__main__":
    app.run(port=5000)
