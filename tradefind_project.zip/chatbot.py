import json, sqlite3, os, re
DB="/content/tradefind/data/trade.db"
SYS="""You are a trade directory assistant. Extract filters as JSON only.
Countries: UAE, Saudi Arabia, Pakistan, China, India
Products: Oil, Textile, Electronics, Pharmaceuticals
Trade types: export, import
Return ONLY this JSON: {"country":"","product":"","trade_type":"","has_email":false,"has_website":false,"explanation":"one sentence"}"""
def _client():
    from groq import Groq
    k=os.environ.get("GROQ_API_KEY","")
    if not k: raise ValueError("GROQ_API_KEY not set!")
    return Groq(api_key=k)
def _filters(msg):
    r=_client().chat.completions.create(model="llama-3.3-70b-versatile",
        messages=[{"role":"system","content":SYS},{"role":"user","content":msg}],
        temperature=0.1,max_tokens=200)
    raw=re.sub(r"```(?:json)?","",r.choices[0].message.content).strip()
    try: return json.loads(raw)
    except: return {"country":"","product":"","trade_type":"","has_email":False,"has_website":False,"explanation":"Could not parse."}
def _db(f):
    conn=sqlite3.connect(DB); conn.row_factory=sqlite3.Row
    q,p="SELECT * FROM companies WHERE 1=1",[]
    if f.get("country"):    q+=" AND LOWER(country)=LOWER(?)";    p.append(f["country"])
    if f.get("product"):    q+=" AND LOWER(product)=LOWER(?)";    p.append(f["product"])
    if f.get("trade_type"): q+=" AND LOWER(trade_type)=LOWER(?)"  ;p.append(f["trade_type"])
    if f.get("has_email"):  q+=" AND email1 IS NOT NULL AND email1 != \'\'"
    if f.get("has_website"):q+=" AND website IS NOT NULL AND website != \'\'"
    rows=conn.execute(q,p).fetchall(); conn.close(); return [dict(r) for r in rows]
def chat(message,history=None):
    try:
        f=_filters(message); exp=f.pop("explanation",""); cos=_db(f); n=len(cos)
        parts=([f"{v} {k}" for k,v in f.items() if v and k not in("has_email","has_website")]
               +(["with email"] if f.get("has_email") else [])+(["with website"] if f.get("has_website") else []))
        fs=", ".join(parts) if parts else "all categories"
        reply=f"Found **{n}** companies for **{fs}**. {exp}" if n else f"No results for **{fs}**. Try broader filters."
        return {"reply":reply,"companies":cos,"filters":f,"error":None}
    except ValueError as e: return {"reply":str(e),"companies":[],"filters":{},"error":"key_missing"}
    except Exception as e:  return {"reply":f"Error: {e}","companies":[],"filters":{},"error":str(e)}
