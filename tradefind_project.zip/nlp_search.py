import numpy as np, sqlite3, os, pickle
_model=None; _index=None
DB="/content/tradefind/data/trade.db"; CACHE="/content/tradefind/data/nlp.pkl"
def _get_model():
    global _model
    if _model is None:
        from sentence_transformers import SentenceTransformer
        _model=SentenceTransformer("all-MiniLM-L6-v2")
    return _model
def _txt(c): return " ".join(filter(None,[c.get("company_name",""),c.get("product",""),c.get("products",""),c.get("services",""),c.get("country",""),c.get("trade_type","")]))
def build_index(force=False):
    global _index
    if not force and os.path.exists(CACHE):
        with open(CACHE,"rb") as f: _index=pickle.load(f)
        print(f"[NLP] Loaded {len(_index)} companies"); return
    print("[NLP] Building index...")
    conn=sqlite3.connect(DB); conn.row_factory=sqlite3.Row
    rows=[dict(r) for r in conn.execute("SELECT * FROM companies").fetchall()]; conn.close()
    vecs=_get_model().encode([_txt(r) for r in rows],show_progress_bar=True,normalize_embeddings=True)
    _index={r["id"]:(vecs[i],r) for i,r in enumerate(rows)}
    with open(CACHE,"wb") as f: pickle.dump(_index,f)
    print(f"[NLP] Index built for {len(_index)} companies")
def semantic_search(query,country="",trade_type="",top_k=20,threshold=0.25):
    if _index is None: build_index()
    qv=_get_model().encode([query],normalize_embeddings=True)[0]; out=[]
    for cid,(cv,co) in _index.items():
        if country and co.get("country","").lower()!=country.lower(): continue
        if trade_type and co.get("trade_type","").lower()!=trade_type.lower(): continue
        s=float(np.dot(qv,cv))
        if s>=threshold: out.append({**co,"score":round(s,3)})
    return sorted(out,key=lambda x:x["score"],reverse=True)[:top_k]
