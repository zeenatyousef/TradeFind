import sqlite3, os, pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
_vec=None; _mat=None; _cos=None
DB="/content/tradefind/data/trade.db"; CACHE="/content/tradefind/data/tfidf.pkl"
def _txt(c): return " ".join(filter(None,[c.get("company_name",""),c.get("product",""),c.get("products",""),c.get("services",""),c.get("trade_type","")])).lower()
def build_index(force=False):
    global _vec,_mat,_cos
    if not force and os.path.exists(CACHE):
        with open(CACHE,"rb") as f: _vec,_mat,_cos=pickle.load(f)
        print(f"[Rec] Loaded {len(_cos)} companies"); return
    print("[Rec] Building TF-IDF index...")
    conn=sqlite3.connect(DB); conn.row_factory=sqlite3.Row
    _cos=[dict(r) for r in conn.execute("SELECT * FROM companies").fetchall()]; conn.close()
    _vec=TfidfVectorizer(ngram_range=(1,2),min_df=1,stop_words="english")
    _mat=_vec.fit_transform([_txt(c) for c in _cos])
    with open(CACHE,"wb") as f: pickle.dump((_vec,_mat,_cos),f)
    print(f"[Rec] Index built for {len(_cos)} companies")
def get_similar(company_id,top_k=4):
    if _cos is None: build_index()
    idx=next((i for i,c in enumerate(_cos) if c["id"]==company_id),None)
    if idx is None: return []
    scores=cosine_similarity(_mat[idx],_mat).flatten()
    ranked=sorted([(i,s) for i,s in enumerate(scores) if i!=idx],key=lambda x:x[1],reverse=True)
    return [{**_cos[i],"similarity":round(float(s),3)} for i,s in ranked[:top_k] if s>0.05]
